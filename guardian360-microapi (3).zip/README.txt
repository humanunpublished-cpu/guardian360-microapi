Guardian360 Micro API
=======================
Endpoints:
- GET /health
- GET /v1/gov/uk/za
- GET /v1/us/travel
- GET /v1/reliefweb/za?days=21
- GET /v1/gdelt?q=(South Africa)...&hours=24

Env:
- CORS_ORIGIN=https://guardian360.co.za,https://www.guardian360.co.za,https://risk.guardian360.co.za
- PORT=8080
